var slideshow = document.querySelectorAll('.slide');
var dotArea = document.querySelector('#dots');
var i = 0;


for (var j = 0; j < slideshow.length -1; j++)
{
    var newDot = document.createElement('span');
    newDot.classList.add('dot');
    dotArea.appendChild(newDot);
}

var dots = document.querySelectorAll('.dot');

slideshowSlider();

function slideshowSlider()
{
    slideshow[i].classList.add('currentimg');
    dots[i].classList.add('active');
    if (i == 0)
    {
        slideshow[slideshow.length - 1].classList.replace('currentimg', 'previousimg');
        slideshow[1].classList.remove('previousimg');
        dots[slideshow.length - 1].classList.remove('active');
    }
    else
    {
        slideshow[i-1].classList.replace('currentimg', 'previousimg');
        dots[i - 1].classList.remove('active');
        if (i == 1)
        {
            slideshow[slideshow.length - 1].classList.remove('previousimg');
        }
        else
        {
            slideshow[i - 2].classList.remove('previousimg');
        }
    }
    if (i == slideshow.length - 1)
    {
        i = 0;
    }
    else
    {
        i++;
    }
    setTimeout(slideshowSlider, 3000);
}